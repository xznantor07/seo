📄 GitHub Form Upload Guide (Bangla)

✅ এই index.html ফাইল GitHub-এ আপলোড করুন:
1. একটি নতুন GitHub Repository তৈরি করুন (Public)
2. index.html ফাইলটি তাতে Add করুন
3. Settings → Pages → Source: main branch, root নির্বাচন করুন
4. লিংক পাবেন: https://yourusername.github.io/repo-name/

👉 এখন যে কেউ এই ফর্মে ডেটা দিলে তা আপনার Google Sheet-এ জমা হবে!
